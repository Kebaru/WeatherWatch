//
//  InterfaceController.swift
//  WeatherWatch WatchKit Extension
//
//  Created by Кардошевский ИСИП 20 on 01.04.2022.
//

import WatchKit
import Foundation


class InterfaceController: WKInterfaceController {
    
    @IBOutlet weak var inputCity: WKInterfaceTextField!
    @IBOutlet weak var tempLabel: WKInterfaceLabel!
    
    @IBAction func getWeather(_ sender: Any) {
        let urlString = "https://api.weatherapi.com/v1/current.json?key=\(apiKey)&q=London&aqi=no"
        let url = URL(string: urlString)
        
        let session = URLSession(configuration: .default)
        
        let task = session.dataTask(with: url!) {data, response, error in
            if let data = data{
                self.parseJSON(withData: data)
                /*let dataString = String(data: data,encoding: .utf8)
                print(dataString!)*/
            }
        }
        task.resume()
    }

    override func awake(withContext context: Any?) {
        
        
    }
    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
    }
    
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
    }

    
    func parseJSON(withData data: Data){
        let decoder = JSONDecoder()
        do {
            let apiItem = try decoder.decode(Welcome.self, from: data)
            
            DispatchQueue.main.async {
                self.inputCity.setText(String(apiItem.location.name))
                self.tempLabel.setText(String(apiItem.current.tempC)+String("°C"))
            }
        }
        catch let error as NSError{
            print(error.localizedDescription)
        }
    }
}
