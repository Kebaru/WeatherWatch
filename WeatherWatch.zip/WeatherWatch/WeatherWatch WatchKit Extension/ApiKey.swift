//
//  ApiKey.swift
//  WeatherWatch WatchKit Extension
//
//  Created by Кардошевский ИСИП 20 on 01.04.2022.
//

import Foundation

let apiKey = "4993971b7a674505af912330221203"
